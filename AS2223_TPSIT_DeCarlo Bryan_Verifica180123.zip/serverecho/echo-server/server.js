const WebSocket = require("ws"); 
const PORT = 5000;
const wsServer = new WebSocket.Server({
          
    port: PORT
});       

console.log("Il Server è attivo e aspetta pacchetti sulla porta " + wsServer.options.port);
wsServer.on("connection", function (socket) {
    console.log("un client si è appena connesso, i dati del client sono: ");

    if (isNaN(msg*1)) {
        let upd = "";
        switch (msg) {
            case "moltiplica":
                operation = "moltiplicazione";
                break;
            case "raddoppia":
                operation = "raddoppiamento";
                break;
            case "fattoriale":
                    operation = "fattoriale";
                break;     
        }
        socket.send(upd+ "\nho ricevuto il messaggio");
    } else {
        socket.send(bro(msg));
    }
});

function bro(stringa) {
    var _op = operation;
    let numero = parseInt(stringa);
    switch (_op) {
        case "moltiplica":
            return numero*numero;
        case "raddopiamento":
            return numero*2;
    }
}

console.log(`Factorial: ${fattoriale}`)
const factorial = factorialize(number);

function factorialize(numero) {
    if (numero === 0 || numero === 1) return 1;
    for (let i = num - 1; i >= 1; i--) {
      num *= i;
    }
    return num;
  }
  
  
  
  
  


           
    

    
