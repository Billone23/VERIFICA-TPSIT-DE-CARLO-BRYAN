const WebSocket = require("ws"); 
const ServerAddress="ws://127.0.0.1:5000";
const socket = new WebSocket(ServerAddress);
const prompt = require("prompt-sync")({ sigint: true });
const WebSocket = require('ws');

wsClient.on("message", (msg) => {
   console.log(''+msg);
   let messaggio = prompt('Invia un messaggio >\n');
   wsClient.send(messaggio);
});
socket.on("open", function() {
   const numero = prompt("Inserisci un messaggio: ");
   socket.send(num);
});
socket.on("open", function() {
   const num = prompt("Inserisci un messaggio: ");
   socket.send(num);
});

 
 
